#EJERCICIO 4
#Escribe un programa que pida un número entero (n) por pantalla e imprima la suma de los
#números de 1 hasta n.

print("Ejercicio 4 Python")

numero=int(input("Introduce un número por favor."))
suma=0
for i in range(1,numero):
	suma+=i

print("El valor de la suma es: ",suma)
