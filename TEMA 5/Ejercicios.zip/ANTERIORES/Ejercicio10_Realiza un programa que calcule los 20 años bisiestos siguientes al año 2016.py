#EJERCICIO 10
#Realiza un programa que calcule los 20 años bisiestos siguientes al año 2016. Para que un año sea
#bisiesto debe ser divisible por 4, excepto aquellos divisibles entre 100 pero no entre 400

print("Ejercicio 10 Python")

for i in range(2016,2096,4):
	print(f"Es año bisiesto: {i}")


contador=0
anio=2016
while contador<=20:

	if anio%4==0:
		print(anio)
		contador=contador+1
	anio=anio+1
