#EJERCICIO 2
#Escribe un programa que pida nombre y apellidos por teclado y nos escriba por pantalla un saludo indicándonos nuestro nombre.

print("Ejercicio 2 Python")

nombre=input("Introduce tu nombre: ")

apellidos=input("Introduce tus apellidos: ")
print("Hola, te llamas "+nombre+" "+apellidos)
