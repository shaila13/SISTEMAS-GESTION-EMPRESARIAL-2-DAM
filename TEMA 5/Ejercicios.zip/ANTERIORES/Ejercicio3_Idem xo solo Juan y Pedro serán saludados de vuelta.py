#EJERCICIO 3
#Repite el ejercicio anterior, pero en este caso, solo los usuarios Juan y Pedro serán saludados de vuelta.
#Si el nombre es cualquier otro usuario, el programa no hará nada.

print("Ejercicio 2 Python")

nombre=input("Introduce tu nombre: ")

apellidos=input("Introduce tus apellidos: ")

nombreMinusculas=nombre.lower()

if nombreMinusculas in ("juan","pedro"):
	print("Hola, te llamas "+nombre+" "+apellidos)
