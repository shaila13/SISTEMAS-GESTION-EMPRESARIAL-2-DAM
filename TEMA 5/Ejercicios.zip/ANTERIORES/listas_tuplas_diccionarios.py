# Una tupla es inmutable, así que una vez creada no puede ser modificada, una lista es mutable.

#Como keys de un diccionario sólo se pueden usar objectos inmutables, así que una tupla es válida pero una lista no

# Declaramos una lista con diferente tipos de datos
lista = [1, 3.1416, 'j', 'jarroba.com',  True]

print 'Imprimimos los elementos de una lista y el tipo de dato de cada elemento'
for l in lista:
    print '%s - %s' %(l, type(l))


#Listas en Python
lista[i]: #Devuelve el elemento que está en la posición i de la lista.
lista.pop(i): #Devuelve el elemento en la posición i de una lista y luego lo borra.
lista.append(elemento): #Añade elemento al final de la lista.
lista.insert(i, elemento): #Inserta elemento en la posición i.
lista.extend(lista2): #Fusiona lista con lista2.
lista.remove(elemento): #Elimina la primera vez que aparece elemento.

# Declaración de una lista
lista = list()

# Cuenta el número de elementos de la lista
len(lista)

# Agrega un elemento (x) al final de la lista.
lista.append(x)

# Inserta un elemento (x) en una posición determinada (pos)
lista.insert(pos, x)

# Une dos listas (une la lista2 (la que se pasa como parámetro) a la lista)
lista.extend(lista2)

# Borra el primer elemento de la lista cuyo valor sea x. Sino existe devuelve un error
lista.remove(x)

# Borra el elemento en la posición dada de la lista, y lo devuelve.
lista.pop(pos)

# Borra todos los elementos de la lista (lista.clear())
del lista[:]

# Devuelve el índice en la lista del primer elemento cuyo valor sea x.
lista.index(x)

# Devuelve el número de veces que x aparece en la lista.
lista.count(x)

# Ordena los ítems de la lista
lista.sort(cmp=None, key=None, reverse=False)

# Invierte los elementos de la lista.
lista.reverse()

# Devuelve una copia de la lista (lista.copy())
listaCopia = lista[:]

print '\n\n*******    Ordenación de listas    ******'
listaNumero = [5,2,9,1,12,6,8,3,4]

print 'Lista Desordenada'
print listaNumero

print 'Lista ordenada de forma ascendente (Aqui da igual pasarle "reverse=False" como parámetro)'
listaNumero.sort(reverse=False)
print listaNumero

print 'Lista ordenada de forma descendente'
listaNumero.sort(reverse=True)
print listaNumero

#Diccionarios en Python --> los diccionarios no tienen orden. Se crean poniendo sus elementos entre llaves {“a”:”Alicante”, “b”:”Barcelona”,>>>}. 

diccionario={'Piloto 1':'Fernando Alonso', 'Piloto 2':'Kimi Raikkonen', 'Piloto 3':'Felipe Massa'}
print diccionario
# # {'Piloto 1': 'Fernando Alonso', 'Piloto 3': 'Felipe Massa', 'Piloto 2': 'Kimi Raikkonen'}

#diccionario.get(‘key’): Devuelve el valor que corresponde con la key introducida.
#diccionario.pop(‘key’): Devuelve el valor que corresponde con la key introducida, y luego borra la key y el valor.
#diccionario.update({‘key’:’valor’}): Inserta una determinada key o actualiza su valor si ya existiera.
#“key” in diccionario: Devuelve verdadero (True) o falso (False) si la key (no los valores) existe en el diccionario.
#“definicion” in diccionario.values(): Devuelve verdadero (True) o falso (False) si definición existe en el diccionario (no como key).

# get(): Devuelve el valor que corresponde con la key introducida.
print(diccionario.get('Piloto 1'))
# # Fernando Alonso

# pop(): Devuelve el valor que corresponde con la key introducida, y luego borra la key y el valor.
print(diccionario.pop('Piloto 1'))
# # Fernando Alonso
print(diccionario)
# # {'Piloto 3': 'Felipe Massa', 'Piloto 2': 'Kimi Raikkonen'}

# update(): Actualiza el valor de una determinada key o lo crea si no existe.
diccionario.update({'Piloto 4':'Lewis Hamilton'})
diccionario.update({'Piloto 2':'Sebastian Vettel'})
print(diccionario)
# # {'Piloto 4': 'Lewis Hamilton', 'Piloto 2': 'Sebastian Vettel', 'Piloto 3': 'Felipe Massa'}

# "key" in diccionario: devuelve verdadero (True) o falso (False) si la key existe en el diccionario.
print ("Piloto 1" in diccionario)
# # True
print ("piloto 1" in diccionario)
# # False
print ("Sebastian Vettel" in diccionario)
# # False

# "definición" in diccionario.values(): devuelve verdadero (True) o falso (False) si la definición existe en el diccionario.
print ("Sebastian Vettel" in diccionario.values())
# # True

# del diccionario['key']: Elimina el valor (y el key) asociado a la key indicada.
del diccionario['Piloto 2']
print(diccionario)
# # {'Piloto 4': 'Lewis Hamilton', 'Piloto 3': 'Felipe Massa'}