#EJERCICIO 5
#Modifica el programa anterior para que solo los números múltiplos de 3 y de 5 sean sumados.
#EJERCICIO 6
#Escribe un programa que imprima la tabla de multiplicar del 1 al 12.

print("Ejercicio 5 Python")

numero=int(input("Introduce un número por favor."))
suma=0
for i in range(1,numero):

    if i%3==0 or i%5==0:
        suma+=i

print("El valor de la suma es: ",suma)
