#EJERCICIO 9
#Crea un programa que implemente un diccionario. Tendremos palabras y sus definiciones.
#Permitirás añadir palabras y su definición asociada. Existirá una opción en la que podamos
#preguntar al programa por una palabra, y este nos contestará su definición.
import os
print("Ejercicio 9 Python")


diccionario={'homilía':'nombre femenino plural Lecturas del tercer nocturno de los maitines, extraídas de las homilías de los padres y doctores de la Iglesia.',
 'apuntalar':'Poner puntales a una cosa para reforzarla o para que no se derrumbe.',
  'entibar':'Apuntalar las excavaciones de las minas con maderos o armazones metálicos.'}


def menu():

	"""	Función que limpia la pantalla y muestra nuevamente el menu	"""

	os.system('cls') # NOTA para windows tienes que cambiar clear por cls

	print ("Selecciona una opción:")

	print ("\t1 - Buscar una palabra")
	print ("\t2 - Añadir una palabra")
	print ("\t9 - salir")

while True:
	# Mostramos el menu
	menu()
	# solicituamos una opción al usuario
	opcionMenu = input("Inserta un numero valor >> ")

	if opcionMenu=="1":
        palabra = input("Inserta una palabra")
        print(diccionario.get(palabra))
        input("Has pulsado la opción 1...\npulsa una tecla para continuar")

	elif opcionMenu=="2":
        palabra = input("Inserta una palabra")
        definicion = input("Inserta una definicion")
        diccionario.update({palabra:definicion})
		input("Se ha añadido una palabra nueva al diccionario...\npulsa una tecla para continuar")

	elif opcionMenu=="9":
		break
	else:
		print ("")
		input("No has pulsado ninguna opción correcta...\npulsa una tecla para continuar")
