#EJERCICIO 7
#Realiza un programa en el que el usuario tenga que adivinar un número entero. El número a
#adivinar se generará de manera aleatorio. En cada iteración, el programa nos indicará si el número
#a adivinar está por encima o por debajo del que hemos introducido. Cuando el usuario adivine el
#número, le mostrarás el número total de intentos que ha necesitado para ello.
#NOTA: busca en internet como generar números aleatorios en python.
import random

print("Ejercicio 7 Python")

acierto=True
num=random.randint(0,101)
intento=0

while acierto:
	cadena1 = int(input("Escribe un número entre 0 y 100: "))
	if num==cadena1:
		intento=intento+1
		print("Has acertado el número al intento "+str(intento))
        #acierto=False
		break
	else:
		print("No has acertado el número, vuelve a intentarlo.")
		print(num)
		intento=intento+1
		if cadena1>num:
			print("El número que has introducido es mayor que el que tienes que adivinar.")
		else:
			print("El número que has introducido es menor que el que tienes que adivinar.")
