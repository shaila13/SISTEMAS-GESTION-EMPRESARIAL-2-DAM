#EJERCICIO 8
#Escribe un programa que pida una lista de elementos por pantalla y la imprima en orden inverso.
#Pedirás primero el número de elementos y luego los elementos uno a uno. Debes utilizar listas de
#python para la implementación.

import random

print("Ejercicio 8 Python")

lista = []
numeroElementosLista = int(input("Introduzca el número de elementos que va a tener la lista: "))

for i in range(numeroElementosLista):
    #palabra=input("Introduzca una palabra: ")
    lista.append(input("Introduzca una palabra: "))
lista.reverse()
for i in lista:
    print(i)
