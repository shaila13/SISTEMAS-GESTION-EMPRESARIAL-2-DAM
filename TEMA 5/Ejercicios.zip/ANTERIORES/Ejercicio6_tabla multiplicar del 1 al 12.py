#EJERCICIO 6
#Escribe un programa que imprima la tabla de multiplicar del 1 al 12.

print("Ejercicio 6 Python")

tablaMultiplicar=0

for i in range(1,13):
    tablaMultiplicar=i*1
    print(f"1 * {i} =",tablaMultiplicar)
