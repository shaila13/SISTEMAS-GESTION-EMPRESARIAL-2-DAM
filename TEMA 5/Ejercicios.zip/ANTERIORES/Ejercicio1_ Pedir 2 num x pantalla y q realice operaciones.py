#1) Realiza un programa que se capaz de pedir dos números por pantalla y que realice su suma, resta,
#multiplicación y división.

#F5 para compilar y ejecutar
print("Ejercicio 1 Python")
def sumar(op1,op2):
	print("El resultado de la suma es ", op1+op2)

def restar(op1,op2):
	print("El resultado de la resta es ", op1-op2)

def multiplicar(op1,op2):
	print("El resultado de la multiplicación es ", op1*op2)

def dividir(op1,op2):
	print("El resultado de la división es ", op1/op2)

numero1=int(input("Introduce el primer número: "))

numero2=int(input("Introduce el segundo número: "))

sumar(numero1,numero2)
restar(numero1,numero2)
multiplicar(numero1,numero2)
dividir(numero1,numero2)
