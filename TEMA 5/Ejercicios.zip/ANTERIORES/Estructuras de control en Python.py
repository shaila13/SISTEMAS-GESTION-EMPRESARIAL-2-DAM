Alonso_Position=1
if (Alonso_Position==1):
     print("Espectacular Alonso, se ha hecho justicia a pesar del coche")
     print("Ya queda menos para ganar el mundal")
elif (Alonso_Position>1):
     print("Gran carrera de Alonso, lástima que el coche no esté a la altura")
else:
     print("No ha podido terminar la carrera por una avería mecánica")

#while en Python
vuelta=1
while vuelta<10:
     print("Vuelta "+str(vuelta))
     vuelta=vuelta+1

#for en Python
 for vuelta in range(1,10):
     print("Vuelta "+str(vuelta))
